﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eleflex.Security.Web.Security.Users
{
    public class UserRoleViewModel : Eleflex.Security.Message.UserRole
    {

        public string RoleName { get; set; }
    }
}