﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eleflex.Security.Web.Security.Users
{
    public class UserClaimViewModel : Eleflex.Security.Message.UserClaim
    {

        
        
    }
}