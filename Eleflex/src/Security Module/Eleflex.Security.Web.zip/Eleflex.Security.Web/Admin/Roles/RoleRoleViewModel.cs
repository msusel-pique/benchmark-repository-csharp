﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Eleflex.Security.Web.Security.Roles
{
    public class RoleRoleViewModel : Eleflex.Security.Message.RoleRole
    {

        public string RoleName { get; set; }
    }
}